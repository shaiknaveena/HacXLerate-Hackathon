import React from "react";

export default function App(){
  return (
    <div className="min-h-screen font-sans text-gray-800">
      {/* Top bar with contact */}
      <div className="bg-[#f6f9fb] border-b">
        <div className="max-w-6xl mx-auto flex items-center justify-between px-6 py-3 text-sm">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2"><svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M21 8V7a2 2 0 0 0-2-2h-1" stroke="#0b2b3a" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/></svg><span>+91 98765 43210</span></div>
            <div className="flex items-center gap-2"><svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M4 4h16v16H4z" stroke="#0b2b3a" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/></svg><span>info@qwipo.com</span></div>
          </div>
          <div className="text-xs opacity-70">Nandanam, Chennai</div>
        </div>
      </div>

      {/* Header / Nav */}
      <header className="max-w-6xl mx-auto px-6 py-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[#06b6d4] to-[#06f3c6] flex items-center justify-center text-white font-bold">Q</div>
          <div>
            <div className="text-xl font-semibold brand">Qwipo</div>
            <div className="text-xs opacity-70">AI-powered B2B product discovery</div>
          </div>
        </div>
        <nav className="hidden md:flex items-center gap-6 text-sm">
          <a href="#home" className="hover:underline">Home</a>
          <a href="#about" className="hover:underline">About</a>
          <a href="#features" className="hover:underline">Features</a>
          <a href="#testimonials" className="hover:underline">Testimonials</a>
          <a href="#contact" className="bg-[#06b6d4] text-white px-4 py-2 rounded">Contact</a>
        </nav>
      </header>

      {/* Hero similar to sparktales: headline + stats + CTA */}
      <section id="home" className="bg-white">
        <div className="max-w-6xl mx-auto px-6 py-12 grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold brand">Personalized Product Recommendations for Retailers</h1>
            <p className="mt-4 text-gray-700">Qwipo’s hybrid AI engine helps B2B retailers discover relevant products, increase cross-sell and reduce search time — built for distributors and marketplaces.</p>
            <div className="mt-6 flex gap-4">
              <a className="px-5 py-3 bg-[#052a4a] text-white rounded">Get a Demo</a>
              <a className="px-5 py-3 border border-gray-200 rounded">Download Deck</a>
            </div>

            <div className="mt-8 grid grid-cols-3 gap-4 max-w-sm">
              <div className="p-4 bg-[#f6fbff] rounded">
                <div className="text-sm text-gray-600">Retailers onboarded</div>
                <div className="mt-2 text-2xl font-semibold">10,000+</div>
              </div>
              <div className="p-4 bg-[#f6fbff] rounded">
                <div className="text-sm text-gray-600">Expert partners</div>
                <div className="mt-2 text-2xl font-semibold">72+</div>
              </div>
              <div className="p-4 bg-[#f6fbff] rounded">
                <div className="text-sm text-gray-600">Avg search time</div>
                <div className="mt-2 text-2xl font-semibold">-30%</div>
              </div>
            </div>
          </div>

          <div className="rounded-xl shadow p-6 bg-gradient-to-br from-[#e8f7fb] to-white">
            <img src="/Qwipo_AI_AITheme_Presentation.pptx" alt="dashboard mock" className="w-full h-56 object-cover rounded" />
            <div className="mt-4">
              <h4 className="font-semibold">Recommended For You</h4>
              <div className="mt-3 grid grid-cols-2 gap-3">
                <div className="p-3 bg-white rounded border">Product A <div className="text-xs opacity-70">Trending</div></div>
                <div className="p-3 bg-white rounded border">Product B <div className="text-xs opacity-70">Complementary</div></div>
                <div className="p-3 bg-white rounded border">Product C <div className="text-xs opacity-70">New</div></div>
                <div className="p-3 bg-white rounded border">Product D <div className="text-xs opacity-70">Popular</div></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* What we offer / services */}
      <section id="about" className="max-w-6xl mx-auto px-6 py-12">
        <h2 className="text-2xl font-semibold brand">What We Offer</h2>
        <div className="mt-6 grid md:grid-cols-3 gap-6">
          <div className="p-6 border rounded">
            <h4 className="font-semibold">Hybrid Recommendation Engine</h4>
            <p className="text-sm mt-2 text-gray-600">Collaborative + content-based models to surface relevant products.</p>
          </div>
          <div className="p-6 border rounded">
            <h4 className="font-semibold">Context-Aware Suggestions</h4>
            <p className="text-sm mt-2 text-gray-600">Location, seasonality, and business size included in ranking.</p>
          </div>
          <div className="p-6 border rounded">
            <h4 className="font-semibold">Real-time Feeds</h4>
            <p className="text-sm mt-2 text-gray-600">Live recommendations via WebSocket for up-to-date results.</p>
          </div>
        </div>
      </section>

      {/* Featured programs / sections */}
      <section className="bg-[#f8fafc] py-10">
        <div className="max-w-6xl mx-auto px-6">
          <h3 className="text-xl font-semibold">Most Featured Features</h3>
          <div className="mt-6 grid md:grid-cols-3 gap-6">
            <div className="rounded overflow-hidden shadow bg-white">
              <div className="p-6">
                <h4 className="font-semibold">For You Section</h4>
                <p className="text-sm mt-2 text-gray-600">Personalized product tiles for each retailer.</p>
              </div>
            </div>
            <div className="rounded overflow-hidden shadow bg-white">
              <div className="p-6">
                <h4 className="font-semibold">Discover Tab</h4>
                <p className="text-sm mt-2 text-gray-600">Novel product suggestions to encourage exploration.</p>
              </div>
            </div>
            <div className="rounded overflow-hidden shadow bg-white">
              <div className="p-6">
                <h4 className="font-semibold">Business Insights</h4>
                <p className="text-sm mt-2 text-gray-600">Purchase patterns and competitor pricing trends.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="max-w-6xl mx-auto px-6 py-12">
        <h3 className="text-2xl font-semibold brand">Reviews from Retailers</h3>
        <div className="mt-6 grid md:grid-cols-3 gap-6">
          <div className="p-6 border rounded">
            <p className="text-sm">\"Qwipo helped us discover complementary SKUs we never knew existed.\"</p>
            <div className="mt-4 font-semibold">— Ramesh, Store Owner</div>
          </div>
          <div className="p-6 border rounded">
            <p className="text-sm">\"Search time dropped significantly and sales improved.\"</p>
            <div className="mt-4 font-semibold">— Priya, Retail Manager</div>
          </div>
          <div className="p-6 border rounded">
            <p className="text-sm">\"Easy to use dashboard and accurate recommendations.\"</p>
            <div className="mt-4 font-semibold">— Ajay, Distributor</div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#052a4a] text-white mt-12">
        <div className="max-w-6xl mx-auto px-6 py-10 grid md:grid-cols-3 gap-6">
          <div>
            <div className="text-xl font-semibold">Qwipo</div>
            <div className="mt-2 text-sm opacity-80">AI-powered B2B product discovery</div>
          </div>
          <div>
            <div className="font-semibold">Quick Links</div>
            <ul className="mt-2 text-sm opacity-80">
              <li>Home</li>
              <li>About</li>
              <li>Features</li>
              <li>Contact</li>
            </ul>
          </div>
          <div>
            <div className="font-semibold">Contact</div>
            <div className="mt-2 text-sm opacity-80">info@qwipo.com<br/>+91 98765 43210</div>
          </div>
        </div>
        <div className="text-center text-sm opacity-70 py-4">© {new Date().getFullYear()} Qwipo. All rights reserved.</div>
      </footer>
    </div>
  )
}